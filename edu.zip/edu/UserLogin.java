package com.edu;
import java.util.Scanner;

public class UserLogin {

	
		
		

			public static void main(String[] args) {
				String name,password;
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter name");
				name = sc.next();
				System.out.println("Enter password");
				password = sc.next();
				
				if(name.equalsIgnoreCase("admin") && password.equals("admin123")) {
					System.out.println("Valid user");
				}else {
					System.out.println("Invalid user");
				}

			}

		}