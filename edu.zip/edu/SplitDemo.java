package com.edu;


	public class SplitDemo {

		public static void main(String[] args) {
			String s="welocome to EduBridge";
			String str[]=s.split(" ");
			System.out.println(str);
			
//			for(int i=0;i<str.length;i++) {
//				System.out.println(str[i]);
//			}
			
			//using for each loop
			for(String i:str) {
				System.out.println(i);
			}
		}

	}