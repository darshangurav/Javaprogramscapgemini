package com.edu;

public class StringFun {

	public static void main(String[] args) {
		//isBlank, isEmpty, isNull
		
		String s1="";
		String s2=" "; 
		
		System.out.println("Length of s1="+s1.length());
		System.out.println("length of s2="+s2.length());
		
		if(s1.length()==0) {
			System.out.println("String is empty");
		}else {
			System.out.println("string is empty");
		}
		
		//to check string blank
		//use is 
		if(s2.isBlank()) {
			System.out.println("String is blank");
		}else {
			System.out.println("not blank");
		}
		
	}

}